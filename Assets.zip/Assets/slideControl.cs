﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class slideControl : MonoBehaviour {

	private Slider sd;
	public MapController mc;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void sliderAction(){
		if (sd.value < 0) {

		} else if (sd.value > 0) {

		}
	}
}
