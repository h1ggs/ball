﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointerController : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 crosshairLocation = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		crosshairLocation.z = -5;
		transform.position = crosshairLocation;

		//transform.position = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		//Debug.Log (crosshairLocation);
	}
}
