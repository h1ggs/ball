﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapController : MonoBehaviour {

	public float speed;
	private float v;
	private Quaternion q;
	private float rotationZ = 0f;
	private float senstivity = 0.1f;

	// Use this for initialization
	void Start () {


	}
	


	public void RotateObject(){

		rotationZ += Input.GetAxis ("Mouse X") * senstivity;
		//rotationZ += v;
		rotationZ = Mathf.Clamp (rotationZ, -10, 10);

		//transform.rotation = Quaternion.Lerp (transform.rotation, q, speed * Time.deltaTime);
		transform.localEulerAngles = Vector3.Lerp(transform.localEulerAngles, new Vector3(transform.localEulerAngles.x, transform.localEulerAngles.y, -rotationZ),  speed);

		}
		

	void Update(){

		RotateObject ();

	}
}
